# Cleaning Multi Service JC — Website Preview

Static preview of the **Cleaning MSJC** design, ready for **GitHub Pages**. No build step, no server, no database.

> **Preview only.** Data you type is saved in *your own browser* (localStorage) — it is not shared between devices or people. Gmail, Drive, DocuSign and Calendar buttons are not connected. The full app comes later (see `phase-1-foundation`).

## Files

| File | Purpose |
|---|---|
| `index.html` | Entry page — opens the app |
| `cleaning-msjc.dc.html` | The app design (all screens) |
| `support.js` | Runtime that renders the design |
| `vendor/` | React + Babel, stored locally so the site does not depend on outside servers |
| `_ds/…/styles.css`, `_ds_bundle.js` | Modernist design system (colors, type, spacing) |
| `assets/logo-clean-shine-fresh.png` | Logo |
| `app.webmanifest` | "Add to Home Screen" on iPhone/Android |
| `.nojekyll` | **Required** — lets GitHub Pages serve the `_ds` folder |

## Publish on GitHub Pages

1. Upload **all files in this folder** (including `.nojekyll`) to the root of the repo `JCcleaningService`, branch `main`.
2. Repo → **Settings → Pages** → Source: **Deploy from a branch** → Branch: `main` / `(root)` → **Save**.
3. Wait 1–2 minutes. The site will be at:
   `https://<your-github-username>.github.io/JCcleaningService/`

## Test on your computer (optional)

```bash
python3 -m http.server 8000
# open http://localhost:8000
```
Opening the HTML file by double-click may not work — use a local server or GitHub Pages.
